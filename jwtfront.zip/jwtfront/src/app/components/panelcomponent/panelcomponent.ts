import { Component, inject } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Apiservice } from '../../services/apiservice';

interface Campo {
  nombre: string;
  donde: 'ruta' | 'query' | 'cuerpo';
  rol?: boolean;
  valor: string;
}

interface Endpoint {
  metodo: 'GET' | 'POST' | 'PUT' | 'DELETE';
  ruta: string;
  descripcion: string;
  campos: Campo[];
  estado?: number;
  respuesta?: string;
  cargando?: boolean;
}

interface Grupo {
  nombre: string;
  endpoints: Endpoint[];
}

@Component({
  selector: 'app-panelcomponent',
  standalone: false,
  templateUrl: './panelcomponent.html',
  styleUrl: './panelcomponent.css',
})
export class Panelcomponent {
  api = inject(Apiservice);

  grupos: Grupo[] = [
    {
      nombre: 'Autenticación (/auth)',
      endpoints: [
        {
          metodo: 'POST',
          ruta: '/auth/register',
          descripcion: 'Registrar usuario (rol USER)',
          campos: [
            { nombre: 'username', donde: 'cuerpo', valor: '' },
            { nombre: 'password', donde: 'cuerpo', valor: '' },
          ],
        },
        {
          metodo: 'POST',
          ruta: '/auth/login',
          descripcion: 'Iniciar sesión y guardar el token',
          campos: [
            { nombre: 'username', donde: 'cuerpo', valor: '' },
            { nombre: 'password', donde: 'cuerpo', valor: '' },
          ],
        },
      ],
    },
    {
      nombre: 'Usuarios (/user) - requiere token',
      endpoints: [
        { metodo: 'GET', ruta: '/user/getall', descripcion: 'Listar todos los usuarios', campos: [] },
        { metodo: 'GET', ruta: '/user/count', descripcion: 'Contar usuarios', campos: [] },
        {
          metodo: 'GET',
          ruta: '/user/exists/{id}',
          descripcion: 'Verificar si existe un usuario',
          campos: [{ nombre: 'id', donde: 'ruta', valor: '' }],
        },
        {
          metodo: 'GET',
          ruta: '/user/getbyid/{id}',
          descripcion: 'Buscar usuario por id',
          campos: [{ nombre: 'id', donde: 'ruta', valor: '' }],
        },
        {
          metodo: 'POST',
          ruta: '/user/createjson',
          descripcion: 'Crear usuario con JSON (ADMIN)',
          campos: [
            { nombre: 'username', donde: 'cuerpo', valor: '' },
            { nombre: 'password', donde: 'cuerpo', valor: '' },
            { nombre: 'role', donde: 'cuerpo', rol: true, valor: 'USER' },
          ],
        },
        {
          metodo: 'POST',
          ruta: '/user/create',
          descripcion: 'Crear usuario con parámetros (ADMIN)',
          campos: [
            { nombre: 'username', donde: 'query', valor: '' },
            { nombre: 'password', donde: 'query', valor: '' },
            { nombre: 'role', donde: 'query', rol: true, valor: 'USER' },
          ],
        },
        {
          metodo: 'PUT',
          ruta: '/user/updatejson',
          descripcion: 'Actualizar usuario con JSON (ADMIN)',
          campos: [
            { nombre: 'id', donde: 'query', valor: '' },
            { nombre: 'username', donde: 'cuerpo', valor: '' },
            { nombre: 'password', donde: 'cuerpo', valor: '' },
            { nombre: 'role', donde: 'cuerpo', rol: true, valor: '' },
          ],
        },
        {
          metodo: 'PUT',
          ruta: '/user/update',
          descripcion: 'Actualizar usuario con parámetros (ADMIN)',
          campos: [
            { nombre: 'id', donde: 'query', valor: '' },
            { nombre: 'newUsername', donde: 'query', valor: '' },
            { nombre: 'newPassword', donde: 'query', valor: '' },
            { nombre: 'role', donde: 'query', rol: true, valor: '' },
          ],
        },
        {
          metodo: 'DELETE',
          ruta: '/user/deletebyid/{id}',
          descripcion: 'Eliminar usuario por id (ADMIN)',
          campos: [{ nombre: 'id', donde: 'ruta', valor: '' }],
        },
        {
          metodo: 'DELETE',
          ruta: '/user/deletebyname',
          descripcion: 'Eliminar usuario por nombre (ADMIN)',
          campos: [{ nombre: 'name', donde: 'query', valor: '' }],
        },
      ],
    },
  ];

  ejecutar(endpoint: Endpoint): void {
    let url = endpoint.ruta;
    const params: Record<string, string> = {};
    const cuerpo: Record<string, string> = {};
    for (const campo of endpoint.campos) {
      if (campo.donde === 'ruta') {
        url = url.replace(`{${campo.nombre}}`, encodeURIComponent(campo.valor));
      } else if (campo.valor !== '') {
        if (campo.donde === 'query') {
          params[campo.nombre] = campo.valor;
        } else {
          cuerpo[campo.nombre] = campo.valor;
        }
      }
    }
    const tieneCuerpo = endpoint.campos.some((campo) => campo.donde === 'cuerpo');
    endpoint.cargando = true;
    this.api.ejecutar(endpoint.metodo, url, params, tieneCuerpo ? cuerpo : null).subscribe({
      next: (res) => {
        endpoint.cargando = false;
        endpoint.estado = res.status;
        endpoint.respuesta = this.formatear(res.body);
        if (endpoint.ruta === '/auth/login' && res.body) {
          this.api.token = JSON.parse(res.body).token;
        }
      },
      error: (err) => {
        endpoint.cargando = false;
        if (err instanceof HttpErrorResponse && err.status !== 0) {
          endpoint.estado = err.status;
          endpoint.respuesta = this.formatear(err.error);
        } else {
          endpoint.estado = 0;
          endpoint.respuesta = 'No hay conexión con el back';
        }
      },
    });
  }

  formatear(texto: string | null): string {
    if (!texto) {
      return '(sin contenido)';
    }
    try {
      return JSON.stringify(JSON.parse(texto), null, 2);
    } catch {
      return texto;
    }
  }
}
