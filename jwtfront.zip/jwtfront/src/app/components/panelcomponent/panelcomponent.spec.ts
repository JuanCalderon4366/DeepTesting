import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Panelcomponent } from './panelcomponent';

describe('Panelcomponent', () => {
  let component: Panelcomponent;
  let fixture: ComponentFixture<Panelcomponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Panelcomponent],
    }).compileComponents();

    fixture = TestBed.createComponent(Panelcomponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
