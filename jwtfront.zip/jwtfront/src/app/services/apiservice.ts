import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable, timeout } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Apiservice {
  private http = inject(HttpClient);

  get token(): string {
    return localStorage.getItem('token') ?? '';
  }

  set token(valor: string) {
    if (valor) {
      localStorage.setItem('token', valor);
    } else {
      localStorage.removeItem('token');
    }
  }

  ejecutar(
    metodo: string,
    url: string,
    params: Record<string, string>,
    cuerpo: Record<string, string> | null,
  ): Observable<HttpResponse<string>> {
    let headers = new HttpHeaders();
    if (this.token && !url.startsWith('/auth')) {
      headers = headers.set('Authorization', `Bearer ${this.token}`);
    }
    return this.http
      .request(metodo, url, {
        body: cuerpo,
        params: new HttpParams({ fromObject: params }),
        headers,
        observe: 'response',
        responseType: 'text',
      })
      .pipe(timeout(10000));
  }
}
