import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Panelcomponent } from './components/panelcomponent/panelcomponent';

const routes: Routes = [
  { path: '', component: Panelcomponent, title: 'SpringFirstAppJWT' },
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
